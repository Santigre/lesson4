﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallangeDaysBetweenDates
{
    public partial class defualt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void okButton_Click(object sender, EventArgs e)
        {
            DateTime oneCalender = firstCalendar.SelectedDate;

            DateTime twoCalender = secondCalendar.SelectedDate;

            TimeSpan timebetween = twoCalender.Subtract(oneCalender);

            resultLabel.Text = "The time between the dates is " + timebetween.TotalDays.ToString() + " Days";
        }
    }
}